//
//  ImageSelectionViewController.swift
//  ReadBook
//
//  Created by Amam Pratap Singh on 22/02/23.
//

import UIKit

class ImageSelectionViewController: UIViewController {

    @IBOutlet var cameraButton: UIButton!
    @IBOutlet var galleryButton: UIButton!

    var sendPickedImage: ((UIImage?) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
    }

    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "ImageTextVCbackground.png")!)
        cameraButton.layer.cornerRadius = cameraButton.frame.height / 2
        galleryButton.layer.cornerRadius = galleryButton.frame.height / 2
    }

    @IBAction func didTapCamerButton(_ sender: UIButton) {
        let cameraPickerVC = UIImagePickerController()
        cameraPickerVC.sourceType = .camera
        cameraPickerVC.allowsEditing = true
        cameraPickerVC.delegate = self
        present(cameraPickerVC, animated: true)
    }

    @IBAction func didTapGalleryButton(_ sender: UIButton) {
        let imagePickerVC = UIImagePickerController()
        imagePickerVC.sourceType = .photoLibrary
        imagePickerVC.delegate = self
        imagePickerVC.allowsEditing = true
        present(imagePickerVC, animated: true)
    }
}

extension ImageSelectionViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
                sendPickedImage?(image)
            }
            picker.dismiss(animated: true) {
                self.navigationController?.popViewController(animated: true)
            }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
