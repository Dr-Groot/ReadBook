//
//  ImageTextViewController.swift
//  ReadBook
//
//  Created by Amam Pratap Singh on 22/02/23.
//

import UIKit
import AVFoundation
import Vision

class ImageTextViewController: UIViewController {

    @IBOutlet var selectImageButton: UIButton!
    @IBOutlet var textImageView: UIImageView!
    @IBOutlet var convertButton: UIButton!
    @IBOutlet var imageTextView: UITextView!
    @IBOutlet var playPauseButton: UIButton!

    let synthesizer = AVSpeechSynthesizer()
    var imagePresent: Bool?
    var recievedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        imagePresent = false
    }

    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "ImageTextVCbackground.png")!)
        selectImageButton.layer.cornerRadius = selectImageButton.frame.height / 2
        convertButton.layer.cornerRadius = convertButton.frame.height / 2
        playPauseButton.setImage(UIImage(named: "btn_play.png"), for: .normal)
    }

    @IBAction func didTapSelectImageButton(_ sender: UIButton) {
        let imageSelectVc = self.storyboard?.instantiateViewController(withIdentifier: "ImageSelectionViewController") as! ImageSelectionViewController
        imageSelectVc.modalPresentationStyle = .fullScreen

        imageSelectVc.sendPickedImage = { recievedImage in
            if let recievedImage = recievedImage {
                self.textImageView.image = recievedImage
                self.recievedImage = recievedImage
                self.imagePresent = true
            }
        }
        self.navigationController?.pushViewController(imageSelectVc, animated: true)
    }

    @IBAction func didTapConvertButton(_ sender: UIButton) {
        if !(imagePresent ?? true) {
            let alert = UIAlertController(title: "No Image", message: "Please Select Image", preferredStyle: .alert)
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                alert.dismiss(animated: true)
            })
        } else {
            self.requestText()
        }
    }

    @IBAction func didTapPlayPauseButton(_ sender: UIButton) {
        if imageTextView.text.isEmpty {
            let alert = UIAlertController(title: "", message: "Nothing to play", preferredStyle: .alert)
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
                alert.dismiss(animated: true)
            })
        } else {
            requestSound(text: imageTextView.text)
        }
    }

    func requestText() {
        guard let cgImage = self.recievedImage?.cgImage else { return }
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        var request = VNRecognizeTextRequest(completionHandler: nil)
        var text = ""

        request = VNRecognizeTextRequest(completionHandler: {(request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { fatalError("Invalid ovservation")}

            for observation in observations {
                guard let topCandidate = observation.topCandidates(1).first else {
                    print("Not candidate")
                    continue
                }
                text += "\n\(topCandidate.string)"
            }
            DispatchQueue.main.async {
                self.imageTextView.text = text
            }
        })

        request.customWords = ["custOm"]
        request.minimumTextHeight = 0.03125
        request.recognitionLevel = .accurate
        request.recognitionLanguages = ["en_US"]
        request.usesLanguageCorrection = true

        let requests = [request]

        DispatchQueue.global(qos: .userInitiated).async {
            try?handler.perform(requests)
        }
    }

    func requestSound(text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        utterance.rate = 0.5

        synthesizer.speak(utterance)
    }
    
}
