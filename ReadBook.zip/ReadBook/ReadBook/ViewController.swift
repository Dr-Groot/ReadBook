//
//  ViewController.swift
//  ReadBook
//
//  Created by Amam Pratap Singh on 22/02/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var startScanningImageButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
    }

    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "VCbackground.jpg")!)
        startScanningImageButton.layer.cornerRadius = startScanningImageButton.frame.height / 2
    }

    @IBAction func didTapStartScanningImageButton(_ sender: UIButton) {
        let imageTextVC = self.storyboard?.instantiateViewController(withIdentifier: "ImageTextViewController") as! ImageTextViewController
        imageTextVC.modalPresentationStyle = .fullScreen

        self.navigationController?.pushViewController(imageTextVC, animated: true)
    }
}
